//•	Ingresar 5 números, mostrar la suma y el promedio.

#include<stdio.h>
#include<stdlib.h>

int main()
{
    int i;
    float n, suma, promedio;

    suma = 0;

    for(i = 0; i < 5; i++)
    {
        printf("\n Ingrese un numero :");
        scanf("%f", &n);
        suma += n;
    }

    promedio = suma / 5;

    printf("\n La suma de los 5 numeros dados es = %.2f", suma);
    printf("\n El promedio de los 5 numeros dados es = %.2f \n", promedio);
}